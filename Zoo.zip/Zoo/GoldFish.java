
/**
 * Write a description of class Rhino here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GoldFish extends Animal
implements Swimming
{
    public GoldFish()
    {
        // initialise instance variables
        this("Goldy the Gold Fish", "glurp");
    }

    public GoldFish(String name, String description) {
        super(name, description);
    }
    
    @Override
    public String eat(){
        return "Fish Food";
    }
    
    @Override
    public String makeNoise(){
        return "glurp glurp";
    }
    
    @Override
    public String swim()
    {
       return "Splash"; 
    }
}
