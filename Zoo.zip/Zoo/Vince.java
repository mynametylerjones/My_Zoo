
/**
 * Write a description of class Frog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Vince extends Animal
    implements Walking, Swimming, Flying
{
    public Vince()
    {
     this("Hobs", "Im a big kid now");   
    }
    
    public Vince(String name, String description)
    {
     super(name, description);   
    }
    
    @Override
    
    public String eat()
    {
        return "Eats blue rubber ducks";
    }
    
    @Override
    
    public String makeNoise()
    {
      return "abcdefghijklmnopqrstuvwxyz";
    }
    
    @Override
    
    public String walk()
    {
        return "SKRT SKRT";
    }
    
    @Override
    
    public String swim()
    {
        return "*drowning*";
    }
    
    @Override
    
    public String fly()
    {
        return "WOOP WOOP";
    }
}
