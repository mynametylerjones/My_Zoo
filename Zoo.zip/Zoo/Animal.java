
/**
 * Write a description of class Animal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Animal
{
    /*
     * Instance Variables or fields
     * These are equivalent names for the same thing
     * Protected means that these variables are accessible
     * by this class and anything that inherits (extends) this class
     */
    protected String name;
    protected String description;
    //This variable is static; it belongs to the animal class
    public static int numAnimals = 0;
    
    public Animal()
    {
        //Call the other constructor that takes one String parameter
        //passing in none for the name
        //This is called constructor chaining when one constructor
        //calls another
        this("none");
    }
    public Animal(String name)
    {
        //calls the other constructor that takes two Strings paremeters
        //passing in the value referenced by the name variable and
        //none for the descripthion
        this(name, "none");
    }
    public Animal(String name, String description)
    {
        //Set the name and the description for the animal
        this.name = name;
        this.description = description;
        //
        numAnimals++;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return this.name;
    }
    public void setDescription(String description)
    {
        this.description = description;
    }
    public String getDescription()
    {
        return this.description;
    }
    @Override
    public String toString()
    {
        return this.name + ":" + this.description;
    }
    public abstract String eat();
    public abstract String makeNoise();
}
