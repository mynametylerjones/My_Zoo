
/**
 * Write a description of class thwomp here. - Is made of stone or metal
 *
 * @author John Jagger
 * @version 1.0.1
 */
public class Thwomp extends Animal implements Flying
{
    // instance variables - replace the example below with your own
    public Thwomp()
    {
        this("Bricky the Thwomp", "Smash, m-M-MARIO, SMASH!!");
    }
    public Thwomp(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Doesn't eat, they are metal or stone";
    }
    @Override
    public String makeNoise()
    {
        return "HMMMMMA !!";
    }
    @Override
    public String fly()
    {
        return "It hovers in the air wait- THWOOOMP !!";
    }
}
