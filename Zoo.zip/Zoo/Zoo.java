import java.util.List;
import java.util.ArrayList;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
/**
 * Write a description of class ZooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Zoo
{
    static String wl;
    public static void main(String[] args) throws InterruptedException
    {
        List<Animal> animals = new ArrayList<Animal>();
        
        System.out.println("Welcom to the Zoo!\n");
        System.out.print("Building Cages\n");
        delayDots(3);
        System.out.println("Populating the Animals");
        populateAnimals(animals);
        delayDots(3);
        System.out.print("Hiring zookeepers\n");
        delayDots(3);
        
        Scanner in = new Scanner(System.in);
        System.out.println("\nYou are standing in a wondrous zoo. What would you like to do?");
        System.out.println("Type help to find out what you can do.\n");
        String text = in.nextLine();
        String msg = "";
        while(!text.equals("Leave"))
        {
            switch(text)
            {
                case "Help" : 
                msg = "Type: Vist Cages, Look Up, Vist Aquarium, and Look Around.  \nTo hear the animals type Listen, and to watch them eat type Watch.  \nYou can get snacks by Buying Snacks.  \nYou can go to rides.  \nFor a surprise you can Play a game.  \nYou can leave by leaving.";
                break;
                case "Vist Cages" :
                msg = vistCages(animals);
                break;
                case "Look Up" :
                msg = lookUp(animals);
                break;
                case "Look Around" :
                msg = lookAround(animals);
                break;
                case "Turning Around" :
                msg = turn(animals);
                break;
                case "Vist Aquarium" :
                msg = getWet(animals);
                break;
                case "Watch" :
                msg = hungery(animals);
                break;
                case "Listen" :
                msg = listen(animals);
                break;
                case "Buy food" :
                msg = food(animals);
                break;
                case "Go to rides" :
                msg = rides(animals);
                break;
                //case "Play a game" :
                //msg = fight(animals);
                //break;
                default : msg = "You flail hoplessly with indesion.";
            }
            System.out.println("\n" + msg);
            delayDots(3);
            System.out.println("What now?");
            text = in.nextLine();
        }
    }

    public static void populateAnimals(List<Animal> animals)
    {
        Phish a1 = new Phish();
        Trex a2 = new Trex();
        Bokoblin a3 = new Bokoblin();
        MourningDove a4 = new MourningDove();
        Platypus a5 = new Platypus();
        Megalodon a6 = new Megalodon();
        Rhino a7 = new Rhino();
        Lochnessmonster a8 = new Lochnessmonster();
        Walter a9 = new Walter();
        FruitBat a10 = new FruitBat();
        Moblin a11 = new Moblin();
        Abominablesnowman a12 = new Abominablesnowman();
        Droid a13 = new Droid();
        Llama a14 = new Llama();
        Lizalfo a15 = new Lizalfo();
        RedCrowCrane a16 = new RedCrowCrane();
        Bunny a17 = new Bunny();
        GoldFish a18 = new GoldFish();
        RedPanda a19 = new RedPanda();
        FleshMonster a20 = new FleshMonster();
        Duck a21 = new Duck();
        Anaconda a22 = new Anaconda();
        IronTarkus a23 = new IronTarkus();
        LR57CombatDroid a24 = new LR57CombatDroid();
        Thwomp a25 = new Thwomp();
        Vince a26 = new Vince();
        Shark a27 = new Shark();
        JapaneseMacaque a28 = new JapaneseMacaque();
        Bella a29 = new Bella();
        Bigfoot a30 = new Bigfoot();
        Goomba a31 = new Goomba();
        SunBear a32 = new SunBear();
        JapaneseGiantSalamander a33 = new JapaneseGiantSalamander();
        NakedMoleRats a34 = new NakedMoleRats();
        HomunculusFleshPuppet a35 = new HomunculusFleshPuppet();
        
        animals.add(a1);
        animals.add(a2);
        animals.add(a3);
        animals.add(a4);
        animals.add(a5);
        animals.add(a6);
        animals.add(a7);
        animals.add(a8);
        animals.add(a9);
        animals.add(a10);
        animals.add(a11);
        animals.add(a12);
        animals.add(a13);
        animals.add(a14);
        animals.add(a15);
        animals.add(a16);
        animals.add(a17);
        animals.add(a18);
        animals.add(a19);
        animals.add(a20);
        animals.add(a21);
        animals.add(a22);
        animals.add(a23);
        animals.add(a24);
        animals.add(a25);
        animals.add(a26);
        animals.add(a27);
        animals.add(a28);
        animals.add(a29);
        animals.add(a30);
        animals.add(a31);
        animals.add(a32);
        animals.add(a33);
        animals.add(a34);
        animals.add(a35);
    }

    public static String vistCages(List<Animal> animals)
    {
        String msg = "";
        int location = 0;
        for(Animal a : animals)
        {
            msg += location + a.getName() + ": \n      " + a.getDescription() + "\n      ";
            location ++;
        }
        return msg;
    }

    public static String lookUp(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Flying)
            {
                Flying f  = (Flying)a;
                msg += a.getName() + ": \n      " + f.fly() + "\n";
            }
        }
        return msg;
    }

    public static String lookAround(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Walking)
            {
                Walking w  = (Walking)a;
                msg += a.getName() + ": \n      " + w.walk() + "\n";
            }
        }
        return msg;
    }

    public static String turn(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Spinning)
            {
                Spinning s  = (Spinning)a;
                msg += a.getName() + ": \n      " + s.spin() + a.getDescription() + "\n";
            }
        }
        return msg;
    }

    public static String getWet(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Swimming)
            {
                Swimming g  = (Swimming)a;
                msg += a.getName() + ": \n      " + g.swim() + "\n";
            }
        }
        return msg;
    }

    public static String hungery(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      " + a.eat() + "\n";
        }
        return msg;
    }

    public static String listen(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      " + a.makeNoise() + "\n";
        }
        return msg;
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i = 0; i < dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }

    public static String food(List<Animal> animals) throws InterruptedException
    {
        Scanner food = new Scanner(System.in);
        System.out.println("\nWhat would you like to buy?");
        System.out.println("Type help to find out what you can do.\n");
        String text = food.nextLine();
        String msg = "";

        while(!text.equals("Eat"))
        {
            switch(text)
            {
                case "Help" : 
                msg = "You can buy soda, popsicles, ice cream, \npizza, water, and popcorn. \nYou can finish buying buy eating the food.";
                break;
                case "Buy Soda" :
                msg = "You have carbinated water now";
                break;
                case "Buy Popsicles" :
                msg = "You have frozen flavored water now";
                break;
                case "Buy Ice Cream" :
                msg = "You have Dip 'n' Dots now";
                break;
                case "Pizza" :
                msg = "You have ";
                break;
                case "Buy Water" :
                msg = "You have H2O now";
                break;
                case "Buy Popcorn" :
                msg = "Ahhhhhhh, Burnt Popcorn";
                break;
                default : msg = "You flail hoplessly with indesion.";
            }
            
            System.out.println("\n" + msg);
            delayDots(3);
            System.out.println("What now?");
            text = food.nextLine();
        }
        return msg;
    }

    public static String rides(List<Animal> animals) throws InterruptedException
    {
        Scanner ride = new Scanner(System.in);
        System.out.println("\nWhat would you like to ride?");
        System.out.println("Type help to find out what you can do.\n");
        String text = ride.nextLine();
        String msg = "";
        
        while(!text.equals("Get Off"))
        {
            switch(text)
            {
                case "Help" : 
                msg = "You can ride the Feris Wheel, VR, Dropper, \nand Roller Coster.";
                break;
                case "Feris Wheel" :
                msg = "You have achieved nothing by going in circles.";
                break;
                case "VR" :
                msg = "You should live in the real world.";
                break;
                case "Dropper" :
                msg = "AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH";
                break;
                case "Roller Coster" :
                msg = "Ahh the clasics.";
                break;
                default : msg = "You flail hoplessly with indesion.";
            }
            System.out.println("\n" + msg);
            delayDots(3);
            System.out.println("What now?");
            text = ride.nextLine();
        }
        return msg;
    }
}