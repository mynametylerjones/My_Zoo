/**
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public class Lizalfo extends Animal implements Walking, Swimming, Flying
{

    /**
     * Construction for objects of class lizalfo
     */
    public Lizalfo()
    {
        this("Larry the lizalfo" , "''I'm so fricken annoying''");
    }
    public Lizalfo(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Probably eats fish?";
    }
    @Override
    public String makeNoise()
    {
        return "KHAA KHAA";
    }
    @Override
    public String walk()
    {
        return "skitter at the speed of light, hop hop";
    }
    @Override
    public String swim()
    {
        return "submarine mode, water canon enabled";
    }
    @Override
    public String fly()
    {
        return "plumets onto your head with a spear";
    }
    
    
}
