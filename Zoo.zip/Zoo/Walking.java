
public interface Walking
{
    public String walk();
}
