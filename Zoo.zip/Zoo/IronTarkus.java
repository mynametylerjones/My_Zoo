
/**
 * Write a description of class IronTarkus here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class IronTarkus extends Animal
implements Walking
{
    public IronTarkus() {
        this(" Black Iron Tarkus" , "Undefeatable Knight of Berenike");
    }

    public IronTarkus(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("consumes humanity");
    }

    @Override
    public String makeNoise() {
        return("*max poise noises*");
    }

    @Override
    public String walk() {
        return "Stomp and Chad Walk";
    }
}
